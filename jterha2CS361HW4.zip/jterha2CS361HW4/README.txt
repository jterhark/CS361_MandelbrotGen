Jake TerHark - jterha2
CS361 - mandelbrot

To build the project type 'make' in this directory.

To run the project type './mandelbrot'.

To stop generating images, type any value less than -2 for xmin.
A keyboard interrupt (ctrl+c) will also exit the program and free
shared resources

The optional enhancement of displaying the scale information was implemented